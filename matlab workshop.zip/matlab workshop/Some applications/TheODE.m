function result = TheODE(t,y)
result = 2*t +y;
